package com.grisel.petagram;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.Menu;

import java.util.ArrayList;

public class FavPets extends AppCompatActivity {
    ArrayList<ListFavPets> favPets;
    private RecyclerView listFavPets;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fav_pets);

        Toolbar toolbar = findViewById(R.id.actionbarNavBar);
        setSupportActionBar(toolbar);

        listFavPets = findViewById(R.id.listFavPets);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        LinearLayoutManager linearManager = new LinearLayoutManager(this);
        linearManager.setOrientation(LinearLayoutManager.VERTICAL);

        listFavPets.setLayoutManager(linearManager);
        initListFavPets();
        initAdapter();
    }



    public void initAdapter() {
        PetsFavoriteAdapter adapter = new PetsFavoriteAdapter(favPets, this);
        listFavPets.setAdapter(adapter);
    }

    public void initListFavPets() {
        favPets = new ArrayList<ListFavPets>();

        favPets.add(new ListFavPets(R.drawable.camilo, "Camilo", 7));
        favPets.add(new ListFavPets(R.drawable.caramelo, "Caramelo", 8));
        favPets.add(new ListFavPets(R.drawable.conchi, "Conchi", 6));
        favPets.add(new ListFavPets(R.drawable.lolito, "Lolito", 1));
        favPets.add(new ListFavPets(R.drawable.manchas, "Manchas", 3));
    }
}
