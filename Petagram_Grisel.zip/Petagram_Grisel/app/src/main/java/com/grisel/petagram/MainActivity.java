package com.grisel.petagram;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<Pet> pet;
    private RecyclerView listPets;
    ImageView imgStarIcon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.actionbarNavBar);
        setSupportActionBar(toolbar);

        listPets = findViewById(R.id.listPetsId);
        imgStarIcon = findViewById(R.id.imgStar);

        LinearLayoutManager linearManager = new LinearLayoutManager(this);
        linearManager.setOrientation(LinearLayoutManager.VERTICAL);

        listPets.setLayoutManager(linearManager);
        initListPets();
        initAdapter();

        onClick(imgStarIcon);
    }


    public void initAdapter() {
        PetAdapter adapter = new PetAdapter(pet, this);
        listPets.setAdapter(adapter);
    }

    public void initListPets() {
        pet = new ArrayList<Pet>();

        pet.add(new Pet(R.drawable.camilo, "Camilo", 7));
        pet.add(new Pet(R.drawable.caramelo, "Caramelo", 8));
        pet.add(new Pet(R.drawable.conchi, "Conchi", 6));
        pet.add(new Pet(R.drawable.lolito, "Lolito", 1));
        pet.add(new Pet(R.drawable.manchas, "Manchas", 3));
        pet.add(new Pet(R.drawable.pelusa, "Pelusa", 2));
    }

    public void onClick(View v) {
        imgStarIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, FavPets.class);
                startActivity(intent);
            }
        });
    }
}
